#include "bench.h"

static unsigned long bench_mem_cur;
static unsigned long bench_mem_max;
static unsigned long bench_start_time;

void *bench_malloc(size_t size) {
    //printf("malloc size = %lu of %lu\n",size,bench_mem_cur);
    bench_mem_cur += size;
    if (bench_mem_cur > bench_mem_max)
        bench_mem_max = bench_mem_cur;
    size_t *ret = malloc(size + sizeof(size_t));
    *ret = size;
    return &ret[1];
}

void bench_free(void *pos) {
    size_t size = ((size_t*)pos)[-1];
    //printf("free size = %lu of %lu\n",size,bench_mem_cur);
    bench_mem_cur -= size;
    free( (size_t*)pos - 1);
}

void bench_start(void) {
    //puts("START");
    bench_start_time = clock();
    bench_mem_max = 0;
    bench_mem_cur = 0;
}

void bench_stop(unsigned long *elapsed_time, unsigned long *mem_max) {
    //printf("STOP cur = %lu, max = %lu\n",bench_mem_cur, bench_mem_max);
    *elapsed_time = clock() - bench_start_time;
    *mem_max = bench_mem_max;
}
