#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "prov.h"
#include "bench.h"

#define P1SIZE(N,M,DELTA) ((((N)-(M)-(DELTA))*((N)-(M)-(DELTA)+1))/2)
#define P2SIZE(N,M,DELTA) (((N)-(M)-(DELTA))*((M)+(DELTA)))
#define P3SIZE(N,M,DELTA) ((((M)+(DELTA))*((M)+(DELTA)+1))/2)

#define NUM_TRIALS 10

static unsigned long len_secret;
static unsigned long len_public;
static unsigned long len_sig;

void test_key_gen(prov_param_t *param) {
    unsigned long res = 0;
    unsigned long i, j;
    unsigned long elapsed_time, total_elapsed = 0, mem_max;
    
    prov_pkey_t pkey;
    prov_skey_t skey;
    prov_expanded_skey_t expanded_skey;
    
    prov_alloc_pkey(param, &pkey);
    prov_alloc_skey(param, &skey);
    prov_alloc_expanded_skey(param, &expanded_skey);
    
    for (i=0;i<NUM_TRIALS;i++) {
        
        bench_start();
        
        prov_keygen(param, &pkey, &skey);
        prov_expand_secret(param,&expanded_skey,&skey);
        
        bench_stop(&elapsed_time,&mem_max);
        total_elapsed += elapsed_time;
        
        for (j=0;j<param->len_hashed_pkey;j++)
            res += expanded_skey.hashed_pkey[i];
        for (j=0;j<(P2SIZE(param->n,param->m,param->delta)*param->m);j++)
            res += expanded_skey.aux[i];
    }
    
    prov_free_pkey(&pkey);
    prov_free_skey(&skey);
    prov_free_expanded_skey(&expanded_skey);
    
    puts(" KEY GENERATION");
    printf("  Ignored output = %lu\n",res);
    printf("  Seconds = %.2f, Clock ticks = %lu\n",(float) total_elapsed/CLOCKS_PER_SEC/NUM_TRIALS,total_elapsed/NUM_TRIALS);
    printf("  Memory used in bytes = %lu\n",mem_max + len_secret + len_public);
}

void test_sign(prov_param_t *param) {
    unsigned long res = 0;
    unsigned long i, j;
    unsigned long elapsed_time, total_elapsed = 0, mem_max;
    unsigned int len_msg = 5;

    uint8_t msg[] = {72, 101, 108, 108, 111};
    
    prov_pkey_t pkey;
    prov_skey_t skey;
    prov_expanded_skey_t expanded_skey;
    prov_sig_t sig;
    
    prov_alloc_pkey(param, &pkey);
    prov_alloc_skey(param, &skey);
    prov_alloc_expanded_skey(param, &expanded_skey);
    prov_alloc_sig(param, &sig);
    
    prov_keygen(param, &pkey, &skey);
    prov_expand_secret(param,&expanded_skey,&skey);
    
    for (i=0;i<NUM_TRIALS;i++) {
        msg[0] = i;
        
        bench_start();
        
        prov_expanded_sign(param, &sig, &expanded_skey, msg, len_msg);
        
        bench_stop(&elapsed_time,&mem_max);
        total_elapsed += elapsed_time;
            
        for (j=0;j<param->n;j++)
            res += sig.sig[i];
    }
    
    prov_free_pkey(&pkey);
    prov_free_skey(&skey);
    prov_free_expanded_skey(&expanded_skey);
    
    puts(" SIGNATURE");
    printf("  Ignored output = %lu\n",res);
    printf("  Seconds = %.2f, Clock ticks = %lu\n",(float) total_elapsed/CLOCKS_PER_SEC/NUM_TRIALS,total_elapsed/NUM_TRIALS);
    printf("  Memory used in bytes = %lu\n",mem_max + len_secret + len_sig);
}

void test_verify(prov_param_t *param) {
    unsigned long res = 0;
    unsigned long i;
    unsigned long elapsed_time, total_elapsed = 0, mem_max;
    unsigned int len_msg = 5;

    uint8_t msg[] = {72, 101, 108, 108, 111};
    
    prov_pkey_t pkey;
    prov_skey_t skey;
    prov_expanded_skey_t expanded_skey;
    prov_sig_t sig;
    
    prov_alloc_pkey(param, &pkey);
    prov_alloc_skey(param, &skey);
    prov_alloc_expanded_skey(param, &expanded_skey);
    prov_alloc_sig(param, &sig);
    
    prov_keygen(param, &pkey, &skey);
    prov_expand_secret(param,&expanded_skey,&skey);
    
    for (i=0;i<NUM_TRIALS;i++) {
        msg[0] = i;
        prov_expanded_sign(param, &sig, &expanded_skey, msg, len_msg);
        
        bench_start();
        
        res += prov_verify(param, &sig, &pkey, msg, len_msg);
        
        bench_stop(&elapsed_time,&mem_max);
        total_elapsed += elapsed_time;
    }
    
    prov_free_pkey(&pkey);
    prov_free_skey(&skey);
    prov_free_expanded_skey(&expanded_skey);
    
    puts(" VERIFY");
    printf("  Ignored output = %lu\n",res);
    printf("  Seconds = %.2f, Clock ticks = %lu\n",(float) total_elapsed/CLOCKS_PER_SEC/NUM_TRIALS,total_elapsed/NUM_TRIALS);
    printf("  Memory used in bytes = %lu\n",mem_max + len_public + len_sig);
}

int main(void) {
    unsigned int i;
    prov_param_t param[3] = {{136, 46, 8, 16, 16, 24, 32}, {200, 70, 8, 24, 24, 32, 48}, {264, 96, 8, 32, 32, 40, 64}};
    
    printf("Number of trials in each experiment: %u\n",NUM_TRIALS);
    
    srandom(123);
    
    for (i=0;i<3;i++) {
        printf("** PARAM LEVEL %d\n",i+1);
        len_secret = param[i].len_public_seed+param[i].len_secret_seed+param[i].len_hashed_pkey+(P2SIZE(param[i].n,param[i].m,param[i].delta)*param[i].m);
        printf("Size of (extended) secret key: %lu\n",len_secret);
        len_public = param[i].len_public_seed+(P3SIZE(param[i].n,param[i].m,param[i].delta)*param[i].m);
        printf("Size of public key: %lu\n",len_public);
        len_sig = param[i].len_salt+param[i].n;
        printf("Size of sig: %lu\n",len_sig);
        
        test_key_gen(&param[i]);
        
        test_sign(&param[i]);
        
        test_verify(&param[i]);
    }
    
    return 0;
}
