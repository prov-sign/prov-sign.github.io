#ifndef BENCH_H
#define BENCH_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void *bench_malloc(size_t size);

void bench_free(void *pos);

void bench_start(void);

void bench_stop(unsigned long *elapsed_time, unsigned long *mem_max);

#endif /*BENCH_H*/
