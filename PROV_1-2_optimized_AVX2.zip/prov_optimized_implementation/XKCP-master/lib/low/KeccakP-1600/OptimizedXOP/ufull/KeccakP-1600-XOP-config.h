/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600_implementation_config "all rounds unrolled"
#define KeccakP1600_fullUnrolling
