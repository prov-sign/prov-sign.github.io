/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600_implementation_config "12 rounds unrolled"
#define KeccakP1600_unrolling 12
