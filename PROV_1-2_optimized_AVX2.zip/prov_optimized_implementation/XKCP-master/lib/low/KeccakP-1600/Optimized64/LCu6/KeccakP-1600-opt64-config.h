/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600_implementation_config "lane complementing, 6 rounds unrolled"
#define KeccakP1600_unrolling 6
#define KeccakP1600_useLaneComplementing
