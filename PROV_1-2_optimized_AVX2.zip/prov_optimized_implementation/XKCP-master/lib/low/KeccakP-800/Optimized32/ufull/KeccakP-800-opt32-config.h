/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP800_implementation_config "alternate flavor, all rounds unrolled"
#define KeccakP800_fullUnrolling
#define KeccakP800_useFlavorBis
