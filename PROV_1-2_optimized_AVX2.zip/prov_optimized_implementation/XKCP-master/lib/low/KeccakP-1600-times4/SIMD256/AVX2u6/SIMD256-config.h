/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600times4_implementation_config "AVX2, 6 rounds unrolled"
#define KeccakP1600times4_unrolling 6
#define KeccakP1600times4_useAVX2
