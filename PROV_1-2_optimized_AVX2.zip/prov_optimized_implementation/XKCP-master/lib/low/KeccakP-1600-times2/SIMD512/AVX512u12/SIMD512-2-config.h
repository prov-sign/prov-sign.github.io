/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600times2_implementation_config "AVX512, 12 rounds unrolled"
#define KeccakP1600times2_unrolling 12
#define KeccakP1600times2_useAVX512
