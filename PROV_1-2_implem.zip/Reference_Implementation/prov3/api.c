#include <string.h>
#include <stdio.h>

#include "api.h"

#include "prov.h"
#include "rng.h"

#ifdef SUPERCOP
    #include "crypto_sign.h"
#endif

#if PROV_LEVEL == 1
    static prov_param_t param = {142, 49, 8, 16, 16, 24, 32};
#elif PROV_LEVEL == 3
    static prov_param_t param = {206, 74, 8, 24, 24, 32, 48};
#elif PROV_LEVEL == 5
    static prov_param_t param = {270, 100, 8, 32, 32, 40, 64};
#endif

int crypto_sign_keypair(unsigned char *pk, unsigned char *sk) {
    prov_pkey_t pkey;
    prov_skey_t skey;
    
    prov_alloc_pkey(&param, &pkey);
    prov_alloc_skey(&param, &skey);
    
    randombytes(skey.secret_seed,param.len_secret_seed);
    
    prov_keygen(&param, &pkey, &skey);
    
    prov_write_pkey(&param,pk,&pkey);
    
    prov_write_skey(&param,sk,&skey);
    
    prov_free_pkey(&pkey);
    prov_free_skey(&skey);
    
    return 0;
}

int crypto_sign(unsigned char *sm, unsigned long long *smlen,
            const unsigned char *m, unsigned long long mlen,
                const unsigned char *sk) {
    
    *smlen = mlen + CRYPTO_BYTES;
    memcpy(sm, m, mlen);
    
    prov_skey_t skey;
    prov_sig_t sig;
    
    prov_alloc_skey(&param, &skey);
    prov_alloc_sig(&param, &sig);
    
    prov_read_skey(&param,&skey,(unsigned char*)sk);
    
    int ret = prov_sign(&param, &sig, &skey, m, (size_t) mlen);
    
    prov_write_sig(&param,sm+mlen,&sig);

    prov_free_sig(&sig);
    
    return ret;
}

int crypto_sign_open(unsigned char *m, unsigned long long *mlen,
                 const unsigned char *sm, unsigned long long smlen,
                     const unsigned char *pk) {
    
    *mlen = smlen - CRYPTO_BYTES;
    memcpy(m, sm, *mlen);
    
    prov_pkey_t pkey;
    prov_sig_t sig;
    
    prov_alloc_pkey(&param, &pkey);
    prov_alloc_sig(&param, &sig);

    prov_read_pkey(&param,&pkey,(unsigned char*)pk);
    
    prov_read_sig(&param,&sig,(unsigned char*) (sm + (*mlen)));
    
    int ret = prov_verify(&param, &sig, &pkey, m, (size_t) *mlen);
    
    prov_free_pkey(&pkey);
    prov_free_sig(&sig);
    
    return ret;
}
